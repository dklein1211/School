﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BST_Book_HW
{
    public partial class Form1 : Form
    {
        BSTclass myBST = new BSTclass();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void buttonSubmit_Click(object sender, EventArgs e)
        {
            myBST.Add(7, new Book("Top Book", "Auth", 7, 7));
            myBST.Add(4, new Book("2nd Book", "Auth", 4, 4));
            myBST.Add(5, new Book("3rd Book", "Auth", 5, 5));
            myBST.Add(2, new Book("7th Book", "Auth", 2, 2));
            myBST.Add(1, new Book("4th Book", "Auth", 1, 1));
            myBST.Add(10, new Book("5th Book", "Auth", 10, 10));
            myBST.Add(8, new Book("6th Book", "Auth", 8, 8));
            myBST.Add(3, new Book("8th Book", "Auth", 3, 3));
            textBoxTitle.Text = "Books Added";

            //int rating;
            //int isbn;
            //int year;

            //if(textBoxISBN.Text != "") //Catches blank entires that would override the default name.
            //{
            //    int.TryParse(textBoxISBN.Text, out isbn);
            //    int.TryParse(textBoxRating.Text, out rating);
            //    int.TryParse(textBoxYear.Text, out year);
            //    myBST.Add(isbn, new Book(textBoxTitle.Text, textBoxAuthor.Text, rating, year));
            //}

            //textBoxTitle.Clear();
            //textBoxAuthor.Clear();
            //textBoxISBN.Clear();
            //textBoxRating.Clear();
            //textBoxYear.Clear();
        }

        private void buttonFind_Click(object sender, EventArgs e)
        {
            int isbn;
            int.TryParse(textBoxISBN.Text, out isbn);

            Book results;
                        
            results = myBST.Find(isbn);
            textBoxTitle.Text = results.title;
            textBoxAuthor.Text = results.author;
            textBoxRating.Text = Convert.ToString(results.rating);
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            int isbn;
            int.TryParse(textBoxISBN.Text, out isbn);

            myBST.Remove(isbn);
            textBoxISBN.Clear();
        }

        private void buttonGetAll_Click(object sender, EventArgs e)
        {
            List<ISBNclass> data = myBST.GetISBN();
            List<int> dataInt = new List<int>();

            for(int i = 0; i< data.Count; i++)
            {
                dataInt.Add(data.ElementAt(i).ISBN);
            }
            dataGridView1.DataSource = data;
            dataGridView2.DataSource = dataInt;
        }
    }
}
