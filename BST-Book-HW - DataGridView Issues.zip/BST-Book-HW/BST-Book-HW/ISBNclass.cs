﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BST_Book_HW
{
    class ISBNclass
    {
        internal int ISBN { get; set; }

        public ISBNclass(int i)
        {
            ISBN = i;
        }

        public ISBNclass()
        {
            ISBN = 0;
        }

        
    }
}
