﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesPersonFilter 
{
    // A class to define a person, just a name and an age property
    class Person 
    {
        public string Name { get; set; }
        public int Age { get; set; }

     
    }
}
