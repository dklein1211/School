﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using ClassLibraryStack;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        // verify that a newly created stack has no entries
        [TestMethod]
        public void IsInitialStackEmpty()
        {
            SmartStack TestStack = new SmartStack(5);
            int expected = 0;
            int actual = TestStack.Count;
            Assert.AreEqual(expected, actual, "stack was not zero length");
        }


        // verify that after pushing onto the stack, it is not empty
        [TestMethod]
        public void IsNotEmptyAfterPush()
        {
            SmartStack TestStack = new SmartStack(5);
            TestStack.Push(10);
            TestStack.Push(20);
            TestStack.Push(30);
            int expected = 3;
            int actual = TestStack.Count;
            Assert.AreEqual(expected, actual, "stack was not correct count");
        }


        // verify that after pushing 3 onto the stack, peek works
        [TestMethod]
        public void Push3ThenPeak()
        {
            SmartStack TestStack = new SmartStack(5);
            TestStack.Push(10);
            TestStack.Push(20);
            TestStack.Push(30);
            int expected = 30;
            int actual = (int)TestStack.Peek();
            Assert.AreEqual(expected, actual, "peek did not work");
        }

        // verify that after pushing 3 onto the stack, pop one works
        [TestMethod]
        public void Push3ThenPop1()
        {
            SmartStack TestStack = new SmartStack(5);
            TestStack.Push(10);
            TestStack.Push(20);
            TestStack.Push(30);
            int expected = 30;
            int actual = (int)TestStack.Pop();
            Assert.AreEqual(expected, actual, "first pop did not work");
        }

        // verify that after pushing 3 onto the stack, pop 2 works
        [TestMethod]
        public void Push3ThenPop2()
        {
            SmartStack TestStack = new SmartStack(5);
            TestStack.Push(10);
            TestStack.Push(20);
            TestStack.Push(30);
            int expected = 20;
            TestStack.Pop();
            int actual = (int)TestStack.Pop();
            Assert.AreEqual(expected, actual, "2nd pop did not work");
        }

        // verify that after pushing 3, pop 2, count = 1
        [TestMethod]
        public void Push3ThenPop2CountEq1()
        {
            SmartStack TestStack = new SmartStack(5);
            TestStack.Push(10);
            TestStack.Push(20);
            TestStack.Push(30);
            int expected = 1;
            TestStack.Pop();
            TestStack.Pop();
            int actual = TestStack.Count;
            Assert.AreEqual(expected, actual, "incorrect count after push and pop");
        }


        // verify that after pushing 3, pop 2, peek works
        [TestMethod]
        public void Push3ThenPop2Peek()
        {
            SmartStack TestStack = new SmartStack(5);
            TestStack.Push(10);
            TestStack.Push(20);
            TestStack.Push(30);
            int expected = 10;
            TestStack.Pop();
            TestStack.Pop();
            int actual = (int)TestStack.Peek();
            Assert.AreEqual(expected, actual, "peek after pop did not work");
        }
    }
}
