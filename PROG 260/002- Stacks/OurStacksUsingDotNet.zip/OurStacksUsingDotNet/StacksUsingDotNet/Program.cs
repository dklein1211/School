﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StacksUsingDotNet
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack myStack = new Stack();
            // test 1  (already done)
            if (myStack.Count == 0)
                Console.WriteLine("Stack started out empty");
            else
                Console.WriteLine("Somethings wrong, stack started out NON empty?");
          
            //===========
            // begin test 2
            myStack.Push(10);
            myStack.Push(20);
            myStack.Push(30);

          
            if (myStack.Count == 0)
                Console.WriteLine("Stack empty after 3 pushes!");
            else
                Console.WriteLine("Stack contains stuff after 3 pushes!");       
            // end of test 2

            // begin test 3
            int x = (int)myStack.Peek();
            Console.WriteLine("top most element, expecting 30, is {0}", x);
            // end of test 3

            // begin test 4
            x = (int)myStack.Pop();
            Console.WriteLine("top most, exp 30,  element WAS {0}, but we just removed it", x);
            // end of test 4

            // begin test 5
            x = (int)myStack.Pop();
            Console.WriteLine("next element, exp 20 removed is {0}", x);
            // end of test 5

            // begin test 6
            Console.WriteLine("Stack contains {0} item after removing 2 items!", myStack.Count);
            // end of test 6

            // begin test 7
            x = (int)myStack.Peek();
            Console.WriteLine("And that last element still on the stack is {0}", x);
            // end of test 7
            Console.ReadLine();

        }

        
    }
}
  