﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryStack
{
    public class SmartStack
    {
        int[] underlyingArray;
       
        public SmartStack(int size)
        {
            underlyingArray = new int[size];
            _count = 0;
        }
        private int _count;

        public int Count
        {
            get { return _count; }
           // set { _count = value; }
        }


        public void Push(int pushValue)
        {
            underlyingArray[_count] = pushValue;
            _count++;
        }

        public int Peek()
        {
            throw new NotImplementedException();
        }

        public int Pop()
        {
            throw new NotImplementedException();
        }
    }
}
