﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1stLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Linked List InsertInOrder by value test program");
            Console.WriteLine();

            IntLinkedList myLL = new IntLinkedList();

            myLL.InsertInOrder(3);
            Console.WriteLine("testing InsertInOrder, should see 3");
            myLL.Print();
            Console.WriteLine();

            myLL.InsertInOrder(5);
            Console.WriteLine("testing InsertInOrder, should see 3 5");
            myLL.Print();
            Console.WriteLine();

            myLL.InsertInOrder(1);
            Console.WriteLine("testing InsertInOrder, should see 1, 3, 5");
            myLL.Print();
            Console.WriteLine();

            myLL.InsertByValue(4);  // use other name for same method
            Console.WriteLine("testing InsertInOrder, should see 1, 3, 4, 5 ");
            myLL.Print();
            Console.WriteLine();

            
            Console.WriteLine();

            // now test remove bottom, middle, and top

            bool returnValue = myLL.RemoveByValue(6);  // remove beyond size
            Console.WriteLine("testing RemoveAt, should see false");
            Console.WriteLine(returnValue);
            Console.WriteLine();

            myLL.RemoveByValue(5);  // bottom
            Console.WriteLine("testing RemoveAt, should see 1, 3, 4,");
            myLL.Print();
            Console.WriteLine();

            myLL.RemoveByValue(3);  // remove at end
            Console.WriteLine("testing RemoveAt, should see 1, 4");
            myLL.Print();
            Console.WriteLine();

            myLL.RemoveByValue(1);  // remove top
            Console.WriteLine("testing RemoveAt, should see 4");
            myLL.Print();
            Console.WriteLine();

           

            ////Console.WriteLine();
            Console.WriteLine("end of test");
            Console.ReadLine();

        }
    }
}
