﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1stLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            IntLinkedList myLL = new IntLinkedList();

            myLL.InsertAtEnd(3); // test InsertAtEnd when list is empty
            myLL.InsertAtFront(2);
            myLL.InsertAtFront(1);
            myLL.InsertAtEnd(4);  // test InsertAtEnd when list has values

            myLL.Print();  // should write out  1  2  3  4  (uses our 1st print which operates "in the node of interest")
                      
            Console.WriteLine();
            Console.WriteLine();

            // now test removing, starting with list of 4 values on down until list has 1 value
            Console.WriteLine(myLL.RemoveFromEnd());  // should write out  4
            Console.WriteLine(myLL.RemoveFromEnd()); // should write out  3
            Console.WriteLine(myLL.RemoveFromEnd()); // should write out  2
            Console.WriteLine(myLL.RemoveFromEnd()); // should write out  1

            Console.WriteLine();
            try
            {
                 Console.WriteLine(myLL.RemoveFromEnd()); // try to RemoveFromEnd when LL is empty
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);  // should write out the message that Linked List is empty
            }


           
            Console.ReadLine();
        }
    }
}
