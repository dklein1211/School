﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1stLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Linked List InsertAt  by index, test program");
            Console.WriteLine();

            // tests InsertAt(int newData, uint index) -- Add by INDEX and RemoveAt(int index) -- Remove BY INDEX
            // and InsertInOrder(int newData)  (don't have a Clear, but it would just set the frontOfList to null

            IntLinkedList myLL = new IntLinkedList();

            myLL.InsertAt(30, 3);
            Console.WriteLine("testing InsertInOrder, should see 30");
            myLL.Print();
            Console.WriteLine();

            myLL.InsertAt(10, 1);
            Console.WriteLine("testing InsertInOrder, should see 10, 30");
            myLL.Print();
            Console.WriteLine();

            myLL.InsertAt(50, 5);
            Console.WriteLine("testing InsertInOrder, should see 10, 30, 50");
            myLL.Print();
            Console.WriteLine();

            myLL.InsertAt(20, 2);
            Console.WriteLine("testing InsertInOrder, should see 10, 20, 30, 50 ");
            myLL.Print();
            Console.WriteLine();

            myLL.InsertAt(40, 4);
            Console.WriteLine("testing InsertInOrder, should see 10, 20, 30, 40, 50");
            myLL.Print();
            Console.WriteLine();

            // now test remove middle, bottom, and top

            myLL.RemoveAt(3);  // middle
            Console.WriteLine("testing RemoveAt, should see 10, 20, 40, 50");
            myLL.Print();
            Console.WriteLine();

            myLL.RemoveAt(4);  // remove at end
            Console.WriteLine("testing RemoveAt, should see 10, 20, 40");
            myLL.Print();
            Console.WriteLine();

            myLL.RemoveAt(1);  // remove top
            Console.WriteLine("testing RemoveAt, should see 20, 40");
            myLL.Print();
            Console.WriteLine();

            bool returnvalue = myLL.RemoveAt(6);  // remove beyond size
            Console.WriteLine("testing RemoveAt, should see false");
            Console.WriteLine(returnvalue);
            Console.WriteLine();

            //Console.WriteLine();
            Console.WriteLine("end of test");
            Console.ReadLine();

        }
    }
}
