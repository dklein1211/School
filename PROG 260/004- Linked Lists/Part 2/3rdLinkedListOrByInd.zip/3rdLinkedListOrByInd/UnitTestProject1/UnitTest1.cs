﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using _1stLinkedList;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        // create a new list, make sure it knows it is empty
        public void ListIsEmptyTest()
        {
            IntLinkedList myLL = new IntLinkedList();
            bool actual = myLL.RemoveAt(1); // should return false, list is empty

            Assert.IsFalse(actual);
        }

        [TestMethod]
        //insert some values, then use InsertAt to place in a particular location in LL
        // pop 2 off, and our insert should be next
        public void InsertByValueTest()
        {

            IntLinkedList myLL = new IntLinkedList();
            myLL.InsertAtFront(44);
            myLL.InsertAtFront(22);
            myLL.InsertAtFront(11);  // should be 11, 22, 44 now
            // insert into the 3rd position (which is index 3) in the LL
            myLL.InsertAt(55, 3);
            myLL.RemoveFromFront();
            myLL.RemoveFromFront();
            int actual = myLL.RemoveFromFront();

            Assert.AreEqual<int>(55,actual);
        }

        [TestMethod]
        // try and RemoveAt when the location DOES NOT exist 
        public void RemoveAtFailTest()
        {
            IntLinkedList myLL = new IntLinkedList();
            myLL.InsertAtFront(44);
            myLL.InsertAtFront(22);
            myLL.InsertAtFront(11);
            bool actual = myLL.RemoveAt(6); // should return false, no such node exists
            Assert.IsFalse(actual);
        }

        [TestMethod]
        // try and RemoveAt when the location DOES exist 
        public void RemoveAtSuccessTest()
        {
            IntLinkedList myLL = new IntLinkedList();
            myLL.InsertAtFront(44);
            myLL.InsertAtFront(22);
            myLL.InsertAtFront(11);
            bool actual = myLL.RemoveAt(2); // should return false, no such node exists
            Assert.IsTrue(actual);
        }

         [TestMethod]
        // testing InsertInOrder(int newData) 
        public void InsertInOrderTest()
        {
            //IntLinkedList myLL = new IntLinkedList();
            //myLL.InsertAtFront(90);
            //myLL.InsertAtFront(10);

            //myLL.InsertInOrder(50);
            //myLL.InsertInOrder(30);
            //myLL.InsertInOrder(70);
            //// list should now be  10, 30, 50, 70, 90
            //myLL.RemoveFromFront();  // pop the 10
            //myLL.RemoveFromFront();  // pop the 30
            //int actual = myLL.RemoveFromFront();  // should be the 50

            //Assert.AreEqual<int>(50, actual);
           
        }
  
    }
    
}
