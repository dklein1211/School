﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1stLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            IntLinkedList myLL = new IntLinkedList();
            myLL.InsertAtFront(5);
            myLL.InsertAtFront(2);
            myLL.InsertAtFront(7);
            myLL.InsertAtFront(3);

            Console.WriteLine( myLL.Get4thNode() );
           
            Console.ReadLine();
        }
    }
}
