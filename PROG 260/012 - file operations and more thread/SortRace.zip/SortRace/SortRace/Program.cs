﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SortRace
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] BigArrayMS = new int[10000];
            BuildRandomArray(BigArrayMS);
            int[] BigArrayQS = new int[10000];
            int[] BigArrayHS = new int[10000];
            int[] BigArrayEE = new int[10000];
            for (int i = 0; i < BigArrayMS.Length - 1; i++)
            {
                BigArrayQS[i] = BigArrayMS[i];
                BigArrayHS[i] = BigArrayMS[i];
                BigArrayEE[i] = BigArrayMS[i];
            }


            Thread MS = new Thread(MSinstructions);
            Thread QS = new Thread(QSinstructions);
            Thread HS = new Thread(HSinstructions);
            Thread EE = new Thread(EEinstructions);
            MS.Start(BigArrayMS);
            QS.Start(BigArrayQS);
            HS.Start(BigArrayHS);
            EE.Start(BigArrayEE);

            while (MS.IsAlive || QS.IsAlive || HS.IsAlive || EE.IsAlive)
            {
                Thread.Sleep(1000);
                Console.WriteLine("tic");
            }
            Console.WriteLine("Done");
            Console.ReadLine();
        }

        private static void EEinstructions(object foo)
        {
            int[] thisArray = (int[])foo;
            Array.Sort(thisArray);
            Console.WriteLine("EE is done");
        }

        private static void HSinstructions(object foo)
        {
            int[] thisArray = (int[])foo;
            HSsort myHPsort = new HSsort();
            myHPsort.HeapSortDown(ref thisArray);
            Console.WriteLine("HS is done");
        }

        private static void QSinstructions(object foo)
        {
            int[] thisArray = (int[])foo;
            QSsort myQSsort = new QSsort();
            myQSsort.QSort(thisArray);
           
            Console.WriteLine("QS is done");
        }

        private static void MSinstructions(object foo)
        {
            int[] thisArray = (int[])foo;
            MSsort.MergeSort_Recursive(thisArray, 0, thisArray.Length-1);
            Console.WriteLine("MS is done");
        }

        private static void BuildRandomArray(int[] intArrayTest)
        {
            Random rndRandomNumbers = new Random();
            for (int i = 0; i < intArrayTest.Length; i++)
            {
                intArrayTest[i] = i + 1; // initialize the array to have values starting at 1, 2, 3, .. up to the size
            }
            int intRndNum;
            int intTemp;
            for (int i = intArrayTest.Length - 1; i > 0; i--)  // walk from the max to the min+1 in our test array
            {                                                  // no reason to do i = 0 as this will copy to ourselves
                intRndNum = rndRandomNumbers.Next(i + 1);
                intTemp = intArrayTest[intRndNum];
                intArrayTest[intRndNum] = intArrayTest[i];
                intArrayTest[i] = intTemp;
            }
        }
    }
}
