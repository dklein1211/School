﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QwithThreads
{
    class FileNameQueue
    {
        private int qTop;
        private int qBottom;

        FileSpec[] ourData;

        private int counter;

        public int QCount
        {
            get { return counter; }
            set { counter = value; }
        }


        public FileNameQueue(int qSize)  // constructor
        {
            qTop = 0;
            qBottom = 0;
            counter = 0;
            ourData = new FileSpec[qSize];
        }

        public void Enqueue(FileSpec newItem)
        {
            if (counter >= ourData.Length)
            {
                throw new OverflowException("Q is full");
            }

            counter++;
            ourData[qBottom] = newItem;
            if ((qBottom + 1) == ourData.Length)
            {
                qBottom = 0;
            }
            else
            {
                qBottom = qBottom + 1;
            }
        }

        public FileSpec Dequeue()
        {
            if (counter == 0)
            {
                throw new IndexOutOfRangeException("Q is empty");
            }
            FileSpec returnValue = ourData[qTop];
            counter--;
            if ((qTop + 1) == ourData.Length)
            {
                qTop = 0;
            }
            else
            {
                qTop = qTop + 1;
            }
            return returnValue;

        }

        public bool IsEmpty()
        {
            if (counter == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public FileSpec Peek()
        {
            if (counter == 0)
            {
                throw new IndexOutOfRangeException("Q is empty");
            }
            else
            {
                return ourData[qTop];
            }
        }

        public void Clear()
        {
            qTop = 0;
            qBottom = 0;
            QCount = 0;
        }
    }
}
