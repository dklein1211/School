﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace QwithThreads
{
    class Program
    {

        static void Main(string[] args)
        {
            Directory.CreateDirectory(@"c:\users\kurt.friedrich\documents\FilesToWrite");

            // we are in the first thread, which you started when you told VS to "start" (at class Program, method Main)
            Random myRandom = new Random();

            FileNameQueue FileSpecQ = new FileNameQueue(20);

            Thread tProcess = new Thread(ProcessApp);
            tProcess.Start(FileSpecQ);



            while (true)  // we will simulate creating 10 applications, and adding them to the queue
            {
                Console.WriteLine("enter the next sentence");
                string nextSentence = Console.ReadLine();
                if (nextSentence == "7")
                {
                    break;
                }
                string filename = myRandom.Next(1, 10000).ToString();
                filename = filename + ".txt";

                System.IO.TextWriter writeFile = new StreamWriter(@"c:\users\kurt.friedrich\documents\FilesToWrite\" + filename);
                writeFile.WriteLine(nextSentence);
                writeFile.WriteLine(); // write an End Of File
                writeFile.Close(); // otherwise no one else can access, including you!


                //Thread.Sleep(myRandom.Next(2, 5) * 1000); // pretend it takes a 2 to 4 seconds to create a new account  <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                FileSpecQ.Enqueue(new FileSpec() { FileName = filename });
                Console.WriteLine("Submitted another file named: {0}", filename);
                Console.WriteLine();
            }
            tProcess.Abort();
            Console.WriteLine("Program done.");
            Console.ReadLine();
        }


        // here is the 2nd thread, representing another dept in the bank that actually creates new bank accounts from the applicaitons
        private static void ProcessApp(object SomeObject)  // The start method takes a delegate method as an argument, but our delegate method doesn't seem to allow passing specific object types
        {
            FileNameQueue localNameForTheQueue = (FileNameQueue)SomeObject;

            while (true)
            {
                if (localNameForTheQueue.QCount > 0)
                {
                    bool done = false;
                    string tempFileName = localNameForTheQueue.Dequeue().FileName;
                    System.IO.TextReader readFile = new StreamReader(@"c:\users\kurt.friedrich\documents\FilesToWrite\" + tempFileName);
                    while (!done)
                    {
                        string readLine = readFile.ReadLine();
                        if (readLine != null)
                        {
                            Console.WriteLine(readLine);
                        }
                        else
                        {
                            done = true;
                        }
                    }
                    readFile.Close();
                    Console.WriteLine();
                    File.Delete(@"c:\users\kurt.friedrich\documents\FilesToWrite\" + tempFileName);

                }
                else
                {
                    Thread.Sleep(1000);
                }
            }
            // Threads are independent, just sharing one queue.
            Console.WriteLine("Thread 2 done.");
        }
    }
}
