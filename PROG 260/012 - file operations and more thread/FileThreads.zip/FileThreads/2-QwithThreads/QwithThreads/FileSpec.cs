﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QwithThreads
{
    public class FileSpec
    {
        public string FileName { get; set; }
    }
}
