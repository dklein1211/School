﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _260BasicBSTclass
{
    class Program
    {
        static void Main(string[] args)
        {
            BST myBST = new BST();  // instantiate an object of the class BST
            myBST.Add(7, "seven"); 
            myBST.Add(1, "one");
            myBST.Add(3, "three");
            myBST.Add(8, "eight");
            myBST.Add(4, "four");
            myBST.Add(2, "two");
            myBST.Add(5, "five");
            myBST.Add(10, "ten");
            myBST.Add(6, "six");
            myBST.Add(9, "nine");
            
            string result;
            for (int i = 1; i <= 10; i++)
            {
                result = myBST.Find(i);
                if (result != "")
                {
                    Console.WriteLine("Found the value " + result);
                }
                else
                {
                    Console.WriteLine("bug!");
                }
            }

            Console.WriteLine("Program end.");
            Console.ReadLine();
        }
    }

    class BST
    {
        BSTnode bstTop;  // our refernece node at the top of the BST

        class BSTnode  // private (by default) class used by BST
        {
            public int bstKey;
            public BSTnode LeftNode;
            public BSTnode RightNode;
            public string DataValue; // HW - actually hold some data

            public BSTnode(int key, string value)
            {
                bstKey = key;
                DataValue = value;
            }
        }

        public void Add(int keyParam, string dataValueParm)
        {
            if (bstTop == null) // deal with an empty BST
            {
                bstTop = new BSTnode(keyParam, dataValueParm); // add a new node in the bstTop position
                return;   // LeftNode and RightNode will default to null, which is correct
            }
            else  // need to walk the 2 dim tree to find where to add this  
            {
                BSTnode current = bstTop; // since we got here, we know top is not empty

                while (true)
                {
                    if (keyParam < current.bstKey) // if true need to check off to the left
                    {
                        if (current.LeftNode == null) // would mean there are no more nodes on the left
                        {
                            current.LeftNode = new BSTnode(keyParam, dataValueParm); // so make a new one, and change the existing
                            break;  // or return?    we are bailing out of the while
                        }
                        else
                        {
                            current = current.LeftNode;  // walk down a node, and let the while clause do it again
                        }
                      }
                    else if (keyParam > current.bstKey) // else need to check to the rigth
                    {
                        if (current.RightNode == null) // would mean there are no more nodes on the right
                        {
                            current.RightNode = new BSTnode(keyParam, dataValueParm); // so make a new one, and change the existing
                            break;  //  we are bailing out of the while
                        }
                        else
                        {
                            current = current.RightNode;  // walk down a node, and let the while clause do it again
                        }
                    }
                    else  // the key is equal to and existing node, and we don't allow duplicates
	                    {
                            throw new Exception("duplicate values not allowed");
	                    }
                    
                }
            }
        }

        public string Find(int targetKey)  // return true if targetKey value is in the tree <<<<<<<<<<<<<< HW
        {
            if (bstTop == null) // deal with an empty BST
            {
                return "";   // can't be here is there are none  <<<<<<<<<<<<<<<<<< HW
            }
            else  // need to walk the 2 dim tree to try and find it  
            {
                BSTnode current = bstTop; // set our walking pointer node to the top node
                while (current != null) // loop as we walk down the tree unless we get to the bottom before finding it
                {
                    if (targetKey == current.bstKey) // if the current node has the correct value
                    {
                        return current.DataValue;  // we have a match; other wise, we need to move down the right or left branch <<<<<<<<<<<<<<<<<<
                    }
                    else if (targetKey > current.bstKey) // check if we want to follow the left or rigth pointer
                    {
                        current = current.RightNode;  // since target is bigger, we go down the right fork
                        // which might be a null pointer, but our while loop will handle this
                    }
                    else
                    {
                        current = current.LeftNode; // must have been less than, so go down left fork
                    }
                    
                }
                 return "";  // HW <<<<<<<<<<<<<<<<<<<<<<<<<<<<
            }
        }
    }
}
