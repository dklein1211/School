﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections; // added for stack support

namespace _260BasicBSTclass
{
    class Program  // basic code structure from http://leetcode.com/2010/04/binary-search-tree-in-order-traversal.html
    {
        static void Main(string[] args)
        {
            /* Instead of writing this as a recursive method, use a loop and a Stack (of references to BSTNodes) 
             * to accomplish the goal of printing out (in ascending order) all the values in the tree.  
             * Before you try writing the code for this part, spend some time thinking about how to use the stack to
             * simulate the recursive calls.  
              */
            Console.WriteLine("adding 10   6   11   7   9   2   1   4   3   5   8 to BST");
            BST myBST = new BST();  // instantiate an object of the class BST
            myBST.Add(10); // add our first node at the top, and 4 more items
            myBST.Add(6);
            myBST.Add(11);
            myBST.Add(7);
            myBST.Add(9);
            myBST.Add(2);
            myBST.Add(1);
            myBST.Add(4);
            myBST.Add(3);
            myBST.Add(5);
            myBST.Add(8);

            Console.WriteLine();
            Console.WriteLine("printing with prior rec print");
            myBST.Print();  // prints using this class's recursive method
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine("printing with new stack print");
            myBST.PrintWithStack();// prints using new stack method
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Program end.");
            Console.ReadLine();
        }
    }

   
        
}
