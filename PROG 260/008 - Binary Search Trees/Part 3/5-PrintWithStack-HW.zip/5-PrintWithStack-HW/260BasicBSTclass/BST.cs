﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _260BasicBSTclass
{
    class BST
    {
        BSTnode bstTop;  // our refernece node at the top of the BST

        // Note creating a class within a class.  Makes sense as this new class is really a data strcuture
        // which is unique to the outer class.
        class BSTnode  // private (by default) class used by BST
        {
            public int bstKey;  // uses key as "the data item" in our prior linked lists
            public BSTnode LeftNode;  // points to the next node on the left
            public BSTnode RightNode; // points to the next node on the right

            public BSTnode(int key)  // constuctor to create a new node.  It sets the key (data) value, but not the pointers, since 
            // we don'd know at this point where this new node will go in the BST
            {
                bstKey = key;
            }
        }

        //**************************************************************************************************************
        //**************************************************************************************************************
        // new method, prints using .NET stack
        //**************************************************************************************************************
        internal void PrintWithStack() // print the key values of every BST node, in order
        {
            Console.WriteLine("Now printing contents using a stack."); // recursion is great, but for a giant list, may run out of stack frames (memory)
            BSTnode currentBSTnode;  // walk the tree by using this pointer to the current node
            Stack<BSTnode> myStack = new Stack<BSTnode>();  // instantiate the .NET supplied stack class, which will hold objects

            if (bstTop == null) // if the stack is empty ...
            {
                return; // nothing to print
            }
            else // adjust our pointer to the top node in the BST
            {
                currentBSTnode = bstTop;
            }
            bool done = false;  // get out of our while loop when this is set to true
            while (!done)  // loop until we are done
            {
                if (currentBSTnode != null) // if we have not moved down to a null
                {
                    myStack.Push(currentBSTnode); // save this upper node onto the top of the stack
                    currentBSTnode = currentBSTnode.LeftNode;  // and take a step down the left side
                }
                else  // if there is no node here
                {
                    if (myStack.Count == 0)  // and the stack is empty, we have walked the entire tree, so done
                    {
                        done = true;
                    }
                    else  // otherwise go back up the tree one level, by doing a pop
                    {
                        currentBSTnode = (BSTnode)myStack.Pop();  // (need to cast object back to a BSTnode, as the stack doesn't keep track of that)
                        Console.WriteLine(currentBSTnode.bstKey); // write out a value as you come back up
                        currentBSTnode = currentBSTnode.RightNode;  // now go down the rigth side
                    }
                }
            }

        }

        //**************************************************************************************************************
        //**************************************************************************************************************
        // some of our previous methods
        //**************************************************************************************************************

        public void Print()
        {
            PrintRecr(bstTop);
        }

        private void PrintRecr(BSTnode current)
        {
            if (current == null)
            {
                return;
            }
            PrintRecr(current.LeftNode);
            Console.WriteLine(current.bstKey);
            PrintRecr(current.RightNode);              // what will it do if swap the 2 print (left and right) lines??
        }


        // this method will add a new node at the correct location
        public void Add(int keyParam)
        {
            if (bstTop == null) // deal with an empty BST
            {
                bstTop = new BSTnode(keyParam); // add a new node in the bstTop position
                return;   // LeftNode and RightNode will default to null, which is correct
            }
            else  // need to walk the 2 dim tree to find where to add this  
            {
                BSTnode current = bstTop; // since we got here, we know top is not empty

                while (true)
                {
                    if (keyParam < current.bstKey) // if true need to check off to the left
                    {
                        if (current.LeftNode == null) // would mean there are no more nodes on the left
                        {
                            current.LeftNode = new BSTnode(keyParam); // so make a new one, and change the existing
                            // node's left pointer to point to a new node
                            break;  // or return?    we are bailing out of the while
                        }
                        else
                        {
                            current = current.LeftNode;  // walk down a node, and let the while clause do it again
                        }
                    }
                    else if (keyParam > current.bstKey) // else need to check to the rigth
                    {
                        if (current.RightNode == null) // would mean there are no more nodes on the right
                        {
                            current.RightNode = new BSTnode(keyParam); // so make a new one, and change the existing
                            // node's right pointer to point to a new node
                            break;  //  we are bailing out of the while
                        }
                        else
                        {
                            current = current.RightNode;  // walk down a node, and let the while clause do it again
                        }
                    }
                    else  // the key is equal to and existing node, and we don't allow duplicates
                    {
                        throw new Exception("duplicate values not allowed");
                    }

                }
            }
        }


    }
}
