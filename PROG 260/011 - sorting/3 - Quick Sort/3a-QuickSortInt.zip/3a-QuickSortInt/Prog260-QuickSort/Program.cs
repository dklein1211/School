﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog260_QuickSort
{
    class Program
    {
        static void Main(string[] args)
        {
            QuickSort myQuickSort = new QuickSort();

            // start with array that matched PPT
            int[] testArray0 = new int[] { 40, 20, 10, 80, 60, 50, 7, 30, 100, 90, 70 };
            Console.WriteLine("The PPT array before the sort.");
            Console.WriteLine(string.Join("  ", testArray0));
            myQuickSort.QSort(testArray0);  // sort it
            Console.WriteLine();
            Console.WriteLine("The PPT array after the sort.");
            Console.WriteLine(string.Join("  ", testArray0));
            Console.WriteLine();

            Console.ReadLine();

            // try 3 different arrays with different distribution "shapes"
            int[] testArray1 = new int[] { 9, 6, 3, 0, 5, 1, 7, 8, 2, 4 };
            int[] testArray2 = new int[] { 5, 4, 3, 2, 1, 10, 9, 8, 7, 6 };
            int[] testArray3 = new int[] { 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 }; 

            //string.Join is a nice method for writing out an array
            Console.WriteLine("The arrays before the sort.");
            Console.WriteLine(string.Join("  ", testArray1));
            Console.WriteLine(string.Join("  ", testArray2));
            Console.WriteLine(string.Join("  ", testArray3));

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("The arrays after the sort.");
            myQuickSort.QSort(testArray1);
            myQuickSort.QSort(testArray2);
            myQuickSort.QSort(testArray3);
            Console.WriteLine(string.Join("  ", testArray1));
            Console.WriteLine(string.Join("  ", testArray2));
            Console.WriteLine(string.Join("  ", testArray3));
            Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine("Sort the 4th array.");
            DateTime first = DateTime.Now;  // start our clock
            for (int i = 0; i < 100001; i++)
            {
                int[] testArray4 = new int[] { 39, 24, 44, 31, 36, 9, 50, 23, 49, 2, 27, 43, 40, 10, 32, 48,22, 5, 3, 21, 26, 37, 11, 47, 6, 42, 20, 25, 
                    12, 19, 1, 28, 7, 35, 33, 18, 13, 41, 17, 4, 46, 29, 14, 16, 34, 8, 30, 45, 15, 38 };
                myQuickSort.QSort(testArray4);
            }
            DateTime firstEnd = DateTime.Now;  // capture how long it took
            TimeSpan t1 = firstEnd - first;

            // do it again to show results
            int[] testArray4b = new int[] { 39, 24, 44, 31, 36, 9, 50, 23, 49, 2, 27, 43, 40, 10, 32, 48,22, 5, 3, 21, 26, 37, 11, 47, 6, 42, 20, 25, 
                    12, 19, 1, 28, 7, 35, 33, 18, 13, 41, 17, 4, 46, 29, 14, 16, 34, 8, 30, 45, 15, 38 };
            myQuickSort.QSort(testArray4b);
            Console.WriteLine(string.Join("  ", testArray4b));
             Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine("Sort the 5th array.");
            DateTime second = DateTime.Now;
            for (int i = 0; i < 100001; i++)
            {
                int[] testArray5 = new int[] {1, 2,  3,  4,  5,  6,  7,  8,  9,  10,  11,  12,  13,  14,  15,  16,  17,  18,  19,  20,  21,  22,  23,  24, 25,
                26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50 };
                myQuickSort.QSort(testArray5);
            }
            DateTime secondEnd = DateTime.Now;
            TimeSpan t2 = secondEnd - second;

            // do it again to show results
            int[] testArray5b = new int[] {1, 2,  3,  4,  5,  6,  7,  8,  9,  10,  11,  12,  13,  14,  15,  16,  17,  18,  19,  20,  21,  22,  23,  24, 25,
                26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50 };
            myQuickSort.QSort(testArray5b);
            Console.WriteLine(string.Join("  ", testArray5b));

            Console.WriteLine();
            Console.WriteLine("time for random array: {0}  time of in order array: {1}", t1, t2);
            Console.WriteLine();
            Console.WriteLine("end of quicksort program");

            Console.ReadLine();

            //================================================================================================================


            Console.WriteLine();
            Console.WriteLine("Sort array with 1000 elements in order.");
            DateTime third;
            DateTime thirdend;
            TimeSpan t3 = DateTime.Now - DateTime.Now; 
            for (int i = 0; i < 10001; i++)
            {
                int[] testArray6 = new int[1000];
                for (int j = 0; j < testArray6.Length; j++)
                {
                    testArray6[j] = j;
                }
                
                third = DateTime.Now;
                myQuickSort.QSort(testArray6);
                thirdend = DateTime.Now;
                 if (i ==0)
                {
                    t3 = thirdend - third;
                }
                 else
                 {
                     t3 = t3 + (thirdend - third);
                 }
            }

            Console.WriteLine();
            Console.WriteLine("Sort array with 1000 elements in random order.");

            TimeSpan t4 = DateTime.Now - DateTime.Now;
            for (int i = 0; i < 10001; i++)
            {
                int[] testArray6 = new int[1000];
                testArray6 = UniqueRandomArray(1000, 0, 9999);

                third = DateTime.Now;
                myQuickSort.QSort(testArray6);
                thirdend = DateTime.Now;
                if (i == 0)
                {
                    t4 = thirdend - third;
                }
                else
                {
                    t4 = t4 + (thirdend - third);
                }
            }
           

           
           
            Console.WriteLine();
            Console.WriteLine("times: random 1000: {0}  in order array: {1}", t4, t3);
            Console.WriteLine();
            Console.WriteLine("end of quicksort program");
            Console.ReadLine();
        }

                // this method will build an array of random numbers, making sure no two are the same
        // you set the range of the randmon numbers, lower and upper.
        public static int[] UniqueRandomArray(int arraySize, int Min, int Max)
        {
            int[] UniqueArray = new int[arraySize];
            Random rnd = new Random();
            int Random;
            for (int arrayIndex = 0; arrayIndex < arraySize; arrayIndex++) // walk thru the array and do something for each element
            {
                Random = rnd.Next(Min, Max + 1); // have to add 1 to max because of goofy .NET implimentation of Random
                for (int j = arrayIndex; j >= 0; j--)  // walk from the current arrayPointer backwards down to the 0 element 
                {
                    if (UniqueArray[j] == Random)  // check if we have already used this random number in any of the already assigned spots
                    {
                        Random = rnd.Next(Min, Max + 1);  // if we have used it already, pick a new number, and start back at the current arrayPointer again
                        j = arrayIndex;   // reser the inner loop to start all over again
                    }
                }
                UniqueArray[arrayIndex] = Random; // if none of the slots have used this number, we are free to use it here.
            }
            return UniqueArray;
        }

    }

}
