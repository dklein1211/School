﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BubbleSortFormQuizSol
{
    public partial class Form1 : Form
    {
        List<int> dataList;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int[] rawData = new int[]  { 39, 24, 44, 31, 36, 9, 50, 23, 49, 2, 27, 43, 40, 10, 32, 48,22, 5, 3, 21, 26, 37, 11, 47, 6, 42, 20, 25, 
                    12, 19, 1, 28, 7, 35, 33, 18, 13, 41, 17, 4, 46, 29, 14, 16, 34, 8, 30, 45, 15, 38 };
            dataList = new List<int>();
            for (int i = 0; i < rawData.Length; i++)
            {
                dataList.Add(rawData[i]);
            }
        }

        private void buttonShow_Click(object sender, EventArgs e)
        {
            labelOutput.Text = "";
            foreach (int item in dataList)
            {
                labelOutput.Text = labelOutput.Text + item.ToString() + " ";
            }
        }

        private void buttonSort_Click(object sender, EventArgs e)
        {
            // your sort code goes here.  After user clicks sort, they will need to re-click the Show button to see the updated data





        }
    }
}
