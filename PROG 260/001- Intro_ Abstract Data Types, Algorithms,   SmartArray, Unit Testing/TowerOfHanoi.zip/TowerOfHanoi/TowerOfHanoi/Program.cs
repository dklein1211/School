﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TowerOfHanoi
{
    class Program
    {
        static Stack<string> OneStack = new Stack<string>();
        static Stack<string> TwoStack = new Stack<string>();
        static Stack<string> ThreeStack = new Stack<string>();
        static int count;

        static void Main(string[] args)
        {
            count = 0;
            bool autorun = true;
            string from = "0";
            string to = "0";
            OneStack.Push("@@@@@@@@@@@@@@@@");
            OneStack.Push("@@@@@@@@@@@@");
            OneStack.Push("@@@@@@@@");
            OneStack.Push("@@@@");
            

            Console.WriteLine("At each turn, enter 1, 2, or 3 to pick tower to move from,");
            Console.WriteLine("and then enter 1, 2, or 3 to pick tower to move to.");
            Console.WriteLine("Entering a 9 for the from will end the game.");
            Console.WriteLine("The game does not enforce cheating. I think 15 moves is the minumum");
            Console.WriteLine();
            DrawStacks();

            Console.WriteLine("Do you want to play  Y or let the computer play itself  C ?");
            string reply = Console.ReadLine();
            if (reply == "y" || reply == "Y")
            {
                autorun = false;
            }
            Random myRNG = new Random();
            while (true)
            {
                count++;
                if (autorun)
                {
                    Console.WriteLine("click enter for next move");
                    //Console.ReadLine();
                    from = myRNG.Next(1, 4).ToString();
                    to = myRNG.Next(1, 4).ToString();
                    Move(from, to);
                }
                else
                {
                    Console.Write("From: ");
                    from = Console.ReadLine();
                    if (from == "9")
                    {
                        break;
                    }
                    Console.Write("To: ");
                    to = Console.ReadLine();
                    Move(from, to);
                }
                DrawStacks();
            }

            Console.WriteLine("goodbye");
            Console.ReadLine();
        }

        private static void Move(string from, string to)
        {
            switch (from)
            {
                case "1":
                    switch (to)
                    {
                        case "1":
                            Console.WriteLine("bad input");
                            break;
                        case "2":
                            if (TwoStack.Count == 4)
                            {
                                Console.WriteLine("Two Post is full");
                                break;
                            }
                            else
                            {
                                // going from 1 to 2
                                if (OneStack.Count == 0)
                                {
                                    Console.WriteLine("illegal move");
                                    break;
                                }
                                else
                                {
                                    if (TwoStack.Count == 0 || OneStack.Peek().Length < TwoStack.Peek().Length)
                                    {
                                        TwoStack.Push(OneStack.Pop());
                                    }
                                    else
                                    {
                                        Console.WriteLine("illegal move");
                                    }
                                }
                            }

                            break;
                        case "3":
                            if (ThreeStack.Count == 4)
                            {
                                Console.WriteLine("Three Post is full");
                                break;
                            }
                            else
                            {
                                // going from 1 to 3
                                if (OneStack.Count == 0)
                                {
                                    Console.WriteLine("illegal move");
                                    break;
                                }
                                else
                                {
                                    if (ThreeStack.Count == 0 || OneStack.Peek().Length < ThreeStack.Peek().Length)
                                    {
                                        ThreeStack.Push(OneStack.Pop());
                                        if (ThreeStack.Count == 4)
                                        {
                                            Console.WriteLine("You Won in {0} moves!", count);
                                            DrawStacks();
                                            Console.ReadLine();
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("illegal move");
                                    }
                                }
                            }

                            break;
                        default:
                            Console.WriteLine("bad input");
                            break;
                    }
                    break;
                case "2":
                    switch (to)
                    {
                        case "1":
                            if (OneStack.Count == 4)
                            {
                                Console.WriteLine("One Post is full");
                                break;
                            }
                            else
                            {
                                // going from 2 to 1
                                if (TwoStack.Count == 0)
                                {
                                    Console.WriteLine("illegal move");
                                    break;
                                }
                                else
                                {
                                    if (OneStack.Count == 0 || TwoStack.Peek().Length < OneStack.Peek().Length)
                                    {
                                        OneStack.Push(TwoStack.Pop());
                                    }
                                    else
                                    {
                                        Console.WriteLine("illegal move");
                                    }
                                }
                            }
                            break;
                        case "2":
                            Console.WriteLine("bad input");
                            break;
                        case "3":
                            if (ThreeStack.Count == 4)
                            {
                                Console.WriteLine("Three Post is full");
                                break;
                            }

                            else
                            {
                                // going from 2 to 3
                                if (TwoStack.Count == 0)
                                {
                                    Console.WriteLine("illegal move");
                                    break;
                                }
                                else
                                {
                                    if (ThreeStack.Count == 0 || TwoStack.Peek().Length < ThreeStack.Peek().Length)
                                    {
                                        ThreeStack.Push(TwoStack.Pop());  
                                        if (ThreeStack.Count == 4)
                                        {
                                            Console.WriteLine("You Won in {0} moves!", count);
                                            DrawStacks();
                                            Console.ReadLine();
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("illegal move");
                                    }
                                }
                            }
                            break;
                        default:
                            Console.WriteLine("bad input");
                            break;
                    }
                    break;
                case "3":
                    switch (to)
                    {
                        case "1":
                            if (OneStack.Count == 4)
                            {
                                Console.WriteLine("One Post is full");
                                break;
                            }
                            else  
                            {
                                // going from 3 to 1
                                if (ThreeStack.Count == 0)
                                {
                                    Console.WriteLine("illegal move");
                                    break;
                                }
                                else
                                {
                                    if (OneStack.Count == 0 || ThreeStack.Peek().Length < OneStack.Peek().Length)
                                    {
                                        OneStack.Push(ThreeStack.Pop());
                                    }
                                    else
                                    {
                                        Console.WriteLine("illegal move");
                                    }
                                }
                            }
                            break;
                        case "2":
                            if (TwoStack.Count == 4)
                            {
                                Console.WriteLine("Two Post is full");
                                break;
                            }
                            else
                            {

                                // going from 3 to 2
                                if (ThreeStack.Count == 0)
                                {
                                    Console.WriteLine("illegal move");
                                    break;
                                }
                                else
                                {
                                    if (TwoStack.Count == 0 || ThreeStack.Peek().Length < TwoStack.Peek().Length)
                                    {
                                        TwoStack.Push(ThreeStack.Pop());
                                    }
                                    else
                                    {
                                        Console.WriteLine("illegal move");
                                    }
                                }
                            }
                            break;
                        case "3":
                            Console.WriteLine("bad input");
                            break;
                        default:
                            Console.WriteLine("bad input");
                            break;
                    }
                    break;

                default:
                    Console.WriteLine("bad input");
                    break;
            }
        }

        private static void DrawStacks()
        {
            string[] OneArray = new string[4];
            string[] TwoArray = new string[4];
            string[] ThreeArray = new string[4];

            for (int i = OneArray.Length-1; i >= 0; i--)
            {
                if (OneStack.Count != 0)
                {
                    OneArray[i] = OneStack.Pop();
                }
                else
                {
                    OneArray[i] = "";
                }
            }

            for (int i = TwoArray.Length-1; i >= 0; i--)
            {
                if (TwoStack.Count != 0)
                {
                    TwoArray[i] = TwoStack.Pop();
                }
                else
                {
                    TwoArray[i] = "";
                }
            }


            for (int i = ThreeArray.Length-1; i >= 0; i--)
            {
                if (ThreeStack.Count != 0)
                {
                    ThreeArray[i] = ThreeStack.Pop();
                }
                else
                {
                    ThreeArray[i] = "";
                }
            }



            string OneString = string.Join("__", OneArray);
            OneString = "Post 1: " + OneString;
            string TwoString = string.Join("__", TwoArray);
            TwoString = "Post 2: " + TwoString;
            string ThreeString = string.Join("__", ThreeArray);
            ThreeString = "Post 3: " + ThreeString;

            Console.WriteLine();
            Console.WriteLine(OneString);
            Console.WriteLine(TwoString);
            Console.WriteLine(ThreeString);

            for (int i = 0; i < OneArray.Length; i++)
            {
                if (OneArray[i] != "")
                {
                    OneStack.Push(OneArray[i]);
                }
                //else
                //{
                //    break;
                //}
            }

            for (int i = 0; i < TwoArray.Length; i++)
            {
                if (TwoArray[i] != "")
                {
                    TwoStack.Push(TwoArray[i]);
                }
                //else
                //{
                //    break;
                //}
            }

            for (int i = 0; i < ThreeArray.Length; i++)
            {
                if (ThreeArray[i] != "")
                {
                    ThreeStack.Push(ThreeArray[i]);
                }
                //else
                //{
                //    break;
                //}
            }


        }
    }
}
