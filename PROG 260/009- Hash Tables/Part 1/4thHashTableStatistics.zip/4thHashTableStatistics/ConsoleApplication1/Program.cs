﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        /* 
         * build a hash table with m = 20 (just an integer array) 
         * use Knuth's suggested value of .6180339887 for the Multiplier and build a method
	     * that takes in a integer between 1 and 40 and uses the division algo to return an int
	     * between 0 and 19.  Then Create a method that will populate an array of ints 
	     * with random numbers between 1 and 40  with NO REPEATS
         * The size of the this set of random numbers will be a variable we change, to test how likely collisions are to happen
	     * create a inputKeys array by calling your method
	     * build a loop that cycles thru each of the key values from that array and for each one,
	     * inserts a data value into the hash table array at an index as returned
	     * from your hash table algorithm. For the data value to insert in the hash table,
	     * use the integer you used to create the hash index  (it's not normal to have a key and its value be equal, 
         * but for this program it helps us watch the behavior more easily)
         * detect collisions and write out a message as to what input value and what hash index
	     * caused the collision, but do not correct for the collision.
	     *
         * After that loop, write out the the hash table array values.
         */

        static void Main(string[] args)
        {
            // hash TABLE is size 20, goes from 0 to 19 in that array
            // allowed key range is 1 to 40
            // hash algo takes specified number on entries with keys from 0 thru 39 and hashes into one of our slots, 0 thru 19

            //***********************************************************************************************
            // change how many items we try and stick into the table
            int howMany = 10;  // how many entries we will try and shove in this table of size 20 ( we will change this for fun)
            // program shows you how many times it would take to get a no-collision run.  So 1/that is prob of no collision
            //**********************************************************************************************
            int key;
            int numcollisions = 0;
            Int64 numLoops = 0;
            Random myRandom = new Random();
            bool finished = false;
            while (!finished)
            {
                numcollisions = 0;
                numLoops++;
                int[] hashTable = new int[20];  // use an array to hold the data in loc's 0 thru 19. Relying on new array has all values = 0
                // an array value of zero will be our sign that this is an unused location
                // we can also change the size of the hash storage to experiment
                
                // first create specified number of  unique random numbers bewteen 1 and 40
                int[] ourKeys = UniqeRandomArray(howMany, 1, 40);
                finished = true; // assume its a perrfect run
                for (int i = 0; i < howMany; i++)  // insert each of "howMany" entries into the hash table
                    // storing the key value in the hashtable at the location spcified by doing the hash algo on that key
                {
                    key = HashMul(ourKeys[i]); // calc the hash location pointer from the key value
                    Console.Write("next ranNumber " + ourKeys[i] + "  its key is " + key);  // walk thru that array from 0 to 9
                    if (hashTable[key] == 0)  // zero value means this slot is empty, so we can write our data (= to our key) here.
                    {
                        hashTable[key] = ourKeys[i];
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.WriteLine("  <<< collision  at " + key); // else this spot was used.
                        numcollisions++;  // count the collision occurance
                        finished = false; // guess it wasn't a perfect run, set our flag
                    }
                }

                for (int j = 0; j < 20; j++)
                {
                    Console.WriteLine("{0,3}    {1,3}", j, hashTable[j]);
                }
                Console.WriteLine();
                Console.WriteLine("Had {0} collisions.", numcollisions);
                Console.WriteLine();
            }
            Console.WriteLine();
            Console.WriteLine("It took {0} loops to get a perfect run.", numLoops);
            Console.ReadLine();
        }

        static public int HashMul(int key)
        {
            int tableSize = 20;
            double Multiplier = .6180339887;  // must be > 0 but less than 1
            // Knuth suggests .6180339887 Multiplier 
            double dblKey = key; // convert the int key into a double precision floating point
            double percent = Multiplier * dblKey;
            percent = percent - (int)percent; // get the fractional part
            return (int)(Math.Floor(percent * tableSize)); // round down to make sure you have a number that is within the table size
        }

        // this method will build an array of random numbers, making sure no two are the same
        // you set the range of the randmon numbers, lower and upper.
        public static int[] UniqeRandomArray(int arraySize, int Min, int Max)
        {
            int[] UniqueArray = new int[arraySize];
            Random rnd = new Random();
            int Random;
            for (int arrayIndex = 0; arrayIndex < arraySize; arrayIndex++) // walk thru the array and do something for each element
            {
                Random = rnd.Next(Min, Max+1); // have to add 1 to max because of goofy .NET implimentation of Random
                for (int j = arrayIndex; j >= 0; j--)  // walk from the current arrayPointer backwards down to the 0 element 
                {
                    if (UniqueArray[j] == Random)  // check if we have already used this random number in any of the already assigned spots
                    { 
                        Random = rnd.Next(Min, Max+1);  // if we have used it already, pick a new number, and start back at the current arrayPointer again
                        j = arrayIndex;   // reser the inner loop to start all over again
                    }
                }
                UniqueArray[arrayIndex] = Random; // if none of the slots have used this number, we are free to use it here.
            }
            return UniqueArray;
        }



        /*
        296  with 15 from 400 into 20
        39,361 with 15 from 400 into 20
        1718    with 15 from 400 into 20
        110   with 15 from 400 into 20
        342   with 15 from 400 into 20

        203 with 15 from 40 into 20
        294 with 15 from 40 into 20
        133 with 15 from 40 into 20
        318

        ===================================

        2,059 with 16 from 40 into 20
        1,196 with 16 from 40 into 20
        3,178 with 16 from 40 into 20

        2,017 with 16 from 80 into 20
        7,822 with 16 from 80 into 20
        56    with 16 from 80 into 20

        6,400  with 16 from 200 into 20
        26,747 with 16 from 200 into 20
        7,505  with 16 from 200 into 20

        5,675  with 16 from 400 into 20
        7,436  with 16 from 400 into 20
        58,250 with 16 from 400 into 20
        12,946 with 16 from 400 into 20

        ====================================

        8012 with 17 from 40 into 20
        34    with 17 from 40 into 20
        694  with 17 from 40 into 20
        1132  with 17 from 40 into 20
         

        ====================================
 
        10,486 with 19 from 40 into 20
        20,624 with 19 from 40 into 20
        83,172 with 19 from 40 into 20

        =========================================

        2,220,576  with 20 from 40 into 20
        14,282,667 with 20 from 40 into 20

             */
    }
}
